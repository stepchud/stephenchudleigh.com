/*
 * Created on Jul 7, 2004
 */
package cbg.common;

/**
 * @author Stephen Chudleigh
 **/
public class InvalidCardPlayException extends Exception {

	private static final long serialVersionUID = -7190467688618171335L;

	public InvalidCardPlayException(String arg0) {
		super(arg0);
	}

}
